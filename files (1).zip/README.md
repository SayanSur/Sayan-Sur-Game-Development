# 🐍 Snake Xenzia

**A classic Nokia-style Snake game** — built as a Progressive Web App (PWA).

## Files

| File | Description |
|------|-------------|
| `index.html` | Main HTML shell — phone UI, screen, controls |
| `style.css` | Nokia retro aesthetic, LCD effects, animations |
| `app.js` | Full game engine: snake logic, audio, touch/key input |
| `manifest.json` | PWA manifest — installable on mobile/desktop |
| `sw.js` | Service worker — offline play support |
| `icon.svg` | Vector icon (scalable, any size) |
| `icon-192.png` | PWA icon 192×192 |
| `icon-512.png` | PWA icon 512×512 |

## How to Play

| Input | Action |
|-------|--------|
| Arrow Keys / WASD | Move snake |
| P / Escape | Pause |
| Enter / Space | Start / Resume |
| D-Pad buttons | On-screen direction |
| Swipe on screen | Touch direction control |
| Tap screen | Pause/Resume |

## Features

- 🎮 Classic Nokia Snake Xenzia gameplay
- 🏆 High score leaderboard (localStorage)
- ⚡ 4 speed levels (Slow → Turbo)
- 🌈 3 color themes (Green, Amber, Blue)
- ⭐ Bonus food items (blinking star)
- 📈 Level progression every 5 foods
- 🔊 Web Audio API sound effects
- 📱 PWA — installable on phone/desktop
- 🔌 Offline support via Service Worker
- 📲 Swipe gesture support
- 🌀 Smooth canvas animation loop

## Running Locally

Simply open `index.html` in a browser — no build step needed.

For full PWA features (service worker, install prompt):

```bash
# Using Python
python3 -m http.server 8080

# Using Node
npx serve .
```

Then visit `http://localhost:8080`

## Settings

- **Speed**: Slow / Normal / Fast / Turbo
- **Walls**: ON = walls kill you | OFF = wrap around
- **Sound**: Web Audio API beeps
- **Theme**: Green (classic LCD) / Amber / Blue

---

Made with ❤️ — pure HTML, CSS & JavaScript. No frameworks.

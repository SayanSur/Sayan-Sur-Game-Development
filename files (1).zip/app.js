/* ============================================================
   SNAKE XENZIA — app.js
   Full game logic, audio, PWA, touch, settings
   ============================================================ */

'use strict';

// ─────────────────────────────────────────────────────────────
//  CONSTANTS
// ─────────────────────────────────────────────────────────────
const GRID = 20;   // cells per row/col
const BASE_INTERVAL = 160; // ms per frame at speed Normal

const SPEEDS = [
  { label: 'SLOW',   interval: 220 },
  { label: 'NORMAL', interval: 160 },
  { label: 'FAST',   interval: 110 },
  { label: 'TURBO',  interval:  70 },
];

const THEMES = ['GREEN', 'AMBER', 'BLUE'];

const DIRS = {
  UP:    { x:  0, y: -1 },
  DOWN:  { x:  0, y:  1 },
  LEFT:  { x: -1, y:  0 },
  RIGHT: { x:  1, y:  0 },
};

const OPPOSITE = { UP:'DOWN', DOWN:'UP', LEFT:'RIGHT', RIGHT:'LEFT' };

const SCORE_PER_FOOD   = 10;
const LEVEL_THRESHOLD  = 5;   // foods per level
const MAX_HIGH_SCORES  = 5;

// ─────────────────────────────────────────────────────────────
//  STATE
// ─────────────────────────────────────────────────────────────
let state = {
  phase: 'start',   // start | playing | paused | gameover
  snake: [],        // [{x,y}]
  dir: 'RIGHT',
  nextDir: 'RIGHT',
  food: null,
  bonusFood: null,
  bonusTimer: 0,
  score: 0,
  level: 1,
  foodCount: 0,
  loop: null,
  walls: true,
  soundOn: true,
  speedIdx: 1,
  themeIdx: 0,
  highScores: [],
};

// ─────────────────────────────────────────────────────────────
//  DOM REFS
// ─────────────────────────────────────────────────────────────
const canvas        = document.getElementById('gameCanvas');
const ctx           = canvas.getContext('2d');
const scoreEl       = document.getElementById('scoreDisplay');
const levelEl       = document.getElementById('levelDisplay');
const bestEl        = document.getElementById('bestDisplay');
const finalScoreEl  = document.getElementById('finalScore');
const finalBestEl   = document.getElementById('finalBest');
const newRecordBadge= document.getElementById('newRecordBadge');
const hsListEl      = document.getElementById('highscoreList');
const speedLabel    = document.getElementById('speedLabel');
const themeLabel    = document.getElementById('themeLabel');
const wallsToggle   = document.getElementById('wallsToggle');
const soundToggle   = document.getElementById('soundToggle');

// ─────────────────────────────────────────────────────────────
//  CANVAS SIZE — responsive
// ─────────────────────────────────────────────────────────────
function resizeCanvas() {
  const bezel = document.querySelector('.screen-inner');
  const size  = bezel.clientWidth;
  canvas.width  = size;
  canvas.height = size;
  if (state.phase === 'playing' || state.phase === 'paused') draw();
}
window.addEventListener('resize', resizeCanvas);
setTimeout(resizeCanvas, 100);

function cellSize() { return canvas.width / GRID; }

// ─────────────────────────────────────────────────────────────
//  AUDIO ENGINE (Web Audio API)
// ─────────────────────────────────────────────────────────────
let audioCtx = null;

function getAudioCtx() {
  if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  return audioCtx;
}

function beep(freq, type, duration, gain = 0.3, delay = 0) {
  if (!state.soundOn) return;
  try {
    const ac  = getAudioCtx();
    const osc = ac.createOscillator();
    const g   = ac.createGain();
    osc.connect(g);
    g.connect(ac.destination);
    osc.type      = type;
    osc.frequency.setValueAtTime(freq, ac.currentTime + delay);
    g.gain.setValueAtTime(gain, ac.currentTime + delay);
    g.gain.exponentialRampToValueAtTime(0.001, ac.currentTime + delay + duration);
    osc.start(ac.currentTime + delay);
    osc.stop(ac.currentTime + delay + duration + 0.05);
  } catch(e) {}
}

const SFX = {
  eat()    { beep(880, 'square', 0.08, 0.2); beep(1200,'square', 0.08, 0.2, 0.08); },
  bonus()  { [0,0.08,0.16,0.24].forEach((d,i)=>beep([880,1100,1320,1760][i],'square',0.08,0.25,d)); },
  move()   { beep(160, 'square', 0.02, 0.05); },
  die()    { beep(220,'sawtooth',0.1,0.3); beep(110,'sawtooth',0.2,0.3,0.15); beep(55,'sawtooth',0.3,0.3,0.4); },
  levelup(){ [0,0.1,0.2,0.3].forEach((d,i)=>beep([523,659,784,1047][i],'triangle',0.12,0.25,d)); },
  start()  { beep(440,'triangle',0.05,0.2); beep(880,'triangle',0.08,0.2,0.1); },
};

// ─────────────────────────────────────────────────────────────
//  PIXEL SNAKE ICON (start screen canvas)
// ─────────────────────────────────────────────────────────────
function drawSnakeIcon() {
  const ic  = document.getElementById('snakeIconCanvas');
  const ictx = ic.getContext('2d');
  const cs   = 8;
  const color = getComputedStyle(document.body).getPropertyValue('--pixel-green').trim() || '#4eff91';
  const head  = getComputedStyle(document.body).getPropertyValue('--pixel-bright').trim() || '#a8ffbe';
  const food  = getComputedStyle(document.body).getPropertyValue('--food-color').trim() || '#ff6b35';

  ictx.clearRect(0,0,80,80);

  // Snake body path
  const path = [{x:6,y:4},{x:5,y:4},{x:4,y:4},{x:3,y:4},{x:2,y:4},{x:2,y:5},{x:2,y:6},{x:3,y:6},{x:4,y:6},{x:4,y:7},{x:4,y:8}];
  path.forEach((p,i) => {
    ictx.fillStyle = i===0 ? head : color;
    ictx.shadowColor = color;
    ictx.shadowBlur = 4;
    ictx.fillRect(p.x*cs, p.y*cs, cs-1, cs-1);
  });

  // Food
  ictx.fillStyle = food;
  ictx.shadowColor = food;
  ictx.shadowBlur = 8;
  ictx.fillRect(7*cs, 8*cs, cs-1, cs-1);
  // Tiny dot on food
  ictx.fillStyle = '#fff';
  ictx.shadowBlur = 0;
  ictx.fillRect(7*cs+2, 8*cs+2, 2, 2);
}

// ─────────────────────────────────────────────────────────────
//  ICON.SVG generation (for favicon/PWA)
// ─────────────────────────────────────────────────────────────
function generateIconSVG() {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
  <rect width="512" height="512" rx="80" fill="#0a1a0a"/>
  <rect x="50" y="50" width="412" height="412" rx="20" fill="#0d200d"/>
  <!-- Snake body -->
  <rect x="100" y="180" width="50" height="50" rx="6" fill="#4eff91"/>
  <rect x="158" y="180" width="50" height="50" rx="6" fill="#4eff91"/>
  <rect x="216" y="180" width="50" height="50" rx="6" fill="#4eff91"/>
  <rect x="216" y="238" width="50" height="50" rx="6" fill="#4eff91"/>
  <rect x="216" y="296" width="50" height="50" rx="6" fill="#4eff91"/>
  <rect x="274" y="296" width="50" height="50" rx="6" fill="#4eff91"/>
  <!-- Head -->
  <rect x="332" y="180" width="58" height="58" rx="8" fill="#a8ffbe"/>
  <!-- Eye -->
  <rect x="352" y="196" width="12" height="12" rx="2" fill="#0a1a0a"/>
  <rect x="370" y="196" width="12" height="12" rx="2" fill="#0a1a0a"/>
  <!-- Food -->
  <rect x="332" y="296" width="50" height="50" rx="25" fill="#ff6b35"/>
  <rect x="344" y="308" width="10" height="10" rx="5" fill="rgba(255,255,255,0.5)"/>
</svg>`;
}

// ─────────────────────────────────────────────────────────────
//  STORAGE
// ─────────────────────────────────────────────────────────────
function loadHighScores() {
  try {
    const s = localStorage.getItem('snakeXenzia_hs');
    return s ? JSON.parse(s) : [];
  } catch { return []; }
}

function saveHighScore(score, level) {
  const hs = loadHighScores();
  hs.push({ score, level, date: new Date().toLocaleDateString() });
  hs.sort((a,b) => b.score - a.score);
  const trimmed = hs.slice(0, MAX_HIGH_SCORES);
  try { localStorage.setItem('snakeXenzia_hs', JSON.stringify(trimmed)); } catch {}
  return trimmed;
}

function loadSettings() {
  try {
    const s = localStorage.getItem('snakeXenzia_settings');
    if (s) {
      const p = JSON.parse(s);
      state.walls    = p.walls    ?? true;
      state.soundOn  = p.soundOn  ?? true;
      state.speedIdx = p.speedIdx ?? 1;
      state.themeIdx = p.themeIdx ?? 0;
    }
  } catch {}
}

function saveSettings() {
  try {
    localStorage.setItem('snakeXenzia_settings', JSON.stringify({
      walls:    state.walls,
      soundOn:  state.soundOn,
      speedIdx: state.speedIdx,
      themeIdx: state.themeIdx,
    }));
  } catch {}
}

function getBestScore() {
  const hs = loadHighScores();
  return hs.length ? hs[0].score : 0;
}

// ─────────────────────────────────────────────────────────────
//  GAME LOGIC
// ─────────────────────────────────────────────────────────────
function initSnake() {
  const mid = Math.floor(GRID / 2);
  return [
    { x: mid+1, y: mid },
    { x: mid,   y: mid },
    { x: mid-1, y: mid },
  ];
}

function placeFood(exclude = []) {
  let pos;
  do {
    pos = { x: Math.floor(Math.random()*GRID), y: Math.floor(Math.random()*GRID) };
  } while (
    exclude.some(p => p.x===pos.x && p.y===pos.y) ||
    (state.food && state.food.x===pos.x && state.food.y===pos.y) ||
    (state.bonusFood && state.bonusFood.x===pos.x && state.bonusFood.y===pos.y)
  );
  return pos;
}

function startGame() {
  clearInterval(state.loop);
  state.snake     = initSnake();
  state.dir       = 'RIGHT';
  state.nextDir   = 'RIGHT';
  state.score     = 0;
  state.level     = 1;
  state.foodCount = 0;
  state.food      = placeFood(state.snake);
  state.bonusFood = null;
  state.bonusTimer= 0;
  state.phase     = 'playing';

  updateHUD();
  hideAllOverlays();
  SFX.start();

  const interval = Math.max(50, SPEEDS[state.speedIdx].interval - (state.level-1)*10);
  state.loop = setInterval(gameStep, interval);
  draw();
}

function gameStep() {
  if (state.phase !== 'playing') return;

  state.dir = state.nextDir;
  const head = state.snake[0];
  let nx = head.x + DIRS[state.dir].x;
  let ny = head.y + DIRS[state.dir].y;

  // Wall behaviour
  if (state.walls) {
    if (nx < 0 || nx >= GRID || ny < 0 || ny >= GRID) { endGame(); return; }
  } else {
    nx = (nx + GRID) % GRID;
    ny = (ny + GRID) % GRID;
  }

  // Self collision
  if (state.snake.some(p => p.x===nx && p.y===ny)) { endGame(); return; }

  const newHead = { x: nx, y: ny };
  state.snake.unshift(newHead);

  let ate = false;

  // Eat normal food
  if (nx === state.food.x && ny === state.food.y) {
    ate = true;
    state.score     += SCORE_PER_FOOD * state.level;
    state.foodCount += 1;
    SFX.eat();
    showScorePop(`+${SCORE_PER_FOOD * state.level}`, nx, ny);
    state.food = placeFood(state.snake);

    // Level up
    if (state.foodCount % LEVEL_THRESHOLD === 0) {
      state.level++;
      SFX.levelup();
      flashScreen();
      clearInterval(state.loop);
      const interval = Math.max(50, SPEEDS[state.speedIdx].interval - (state.level-1)*10);
      state.loop = setInterval(gameStep, interval);

      // Spawn bonus food
      state.bonusFood  = placeFood(state.snake);
      state.bonusTimer = 15; // disappears after 15 moves
    }
  }

  // Eat bonus food
  if (state.bonusFood && nx === state.bonusFood.x && ny === state.bonusFood.y) {
    ate = true;
    const bonus = 50 * state.level;
    state.score += bonus;
    SFX.bonus();
    showScorePop(`+${bonus}★`, nx, ny);
    state.bonusFood = null;
  }

  // Bonus food timer
  if (state.bonusFood) {
    state.bonusTimer--;
    if (state.bonusTimer <= 0) state.bonusFood = null;
  }

  if (!ate) state.snake.pop();

  updateHUD();
  draw();
}

function endGame() {
  clearInterval(state.loop);
  state.phase = 'gameover';
  SFX.die();

  // Flash die animation
  flashDie();

  const best    = getBestScore();
  const newBest = state.score > best;
  const hs      = saveHighScore(state.score, state.level);
  state.highScores = hs;

  setTimeout(() => {
    finalScoreEl.textContent = state.score;
    finalBestEl.textContent  = newBest ? state.score : best;
    newRecordBadge.style.display = newBest ? 'block' : 'none';
    bestEl.textContent       = newBest ? state.score : best;
    showOverlay('gameoverScreen');
  }, 700);
}

function pauseGame() {
  if (state.phase === 'playing') {
    clearInterval(state.loop);
    state.phase = 'paused';
    showOverlay('pauseScreen');
  } else if (state.phase === 'paused') {
    resumeGame();
  }
}

function resumeGame() {
  if (state.phase !== 'paused') return;
  state.phase = 'playing';
  hideAllOverlays();
  const interval = Math.max(50, SPEEDS[state.speedIdx].interval - (state.level-1)*10);
  state.loop = setInterval(gameStep, interval);
}

// ─────────────────────────────────────────────────────────────
//  DRAWING
// ─────────────────────────────────────────────────────────────
const CSS = (v) => getComputedStyle(document.documentElement).getPropertyValue(v).trim();

function draw() {
  const cs = cellSize();
  const W  = canvas.width;
  const H  = canvas.height;

  // Background
  ctx.fillStyle = CSS('--screen-bg') || '#0a1a0a';
  ctx.fillRect(0, 0, W, H);

  // Grid lines
  ctx.strokeStyle = CSS('--grid-line') || 'rgba(78,255,145,0.07)';
  ctx.lineWidth = 0.5;
  for (let i = 0; i <= GRID; i++) {
    ctx.beginPath(); ctx.moveTo(i*cs, 0);    ctx.lineTo(i*cs, H);    ctx.stroke();
    ctx.beginPath(); ctx.moveTo(0, i*cs);    ctx.lineTo(W, i*cs);    ctx.stroke();
  }

  // Walls indicator (border glow)
  if (state.walls) {
    ctx.strokeStyle = CSS('--wall-color') || '#2a5a2e';
    ctx.lineWidth = 2;
    ctx.strokeRect(1, 1, W-2, H-2);
  }

  // Food (pulsing)
  if (state.food) {
    const t     = Date.now() / 1000;
    const pulse = 0.85 + 0.15 * Math.sin(t * 6);
    const fc    = CSS('--food-color') || '#ff6b35';
    const fx    = state.food.x * cs + cs/2;
    const fy    = state.food.y * cs + cs/2;
    const fr    = (cs * 0.4) * pulse;

    // Glow
    const grad = ctx.createRadialGradient(fx, fy, 0, fx, fy, fr*2);
    grad.addColorStop(0, fc);
    grad.addColorStop(1, 'transparent');
    ctx.fillStyle = grad;
    ctx.fillRect(state.food.x*cs - cs*0.5, state.food.y*cs - cs*0.5, cs*2, cs*2);

    // Dot
    ctx.fillStyle = fc;
    ctx.shadowColor = fc;
    ctx.shadowBlur  = 12;
    ctx.beginPath();
    ctx.roundRect(state.food.x*cs + cs*0.12, state.food.y*cs + cs*0.12, cs*0.76, cs*0.76, 3);
    ctx.fill();

    // Shine
    ctx.fillStyle = 'rgba(255,255,255,0.5)';
    ctx.shadowBlur = 0;
    ctx.fillRect(state.food.x*cs + cs*0.2, state.food.y*cs + cs*0.2, cs*0.2, cs*0.2);
  }

  // Bonus food (blinking star)
  if (state.bonusFood) {
    const t     = Date.now() / 300;
    const blink = Math.sin(t) > 0;
    if (blink) {
      const bx = state.bonusFood.x * cs;
      const by = state.bonusFood.y * cs;
      ctx.fillStyle = '#fff700';
      ctx.shadowColor = '#fff700';
      ctx.shadowBlur = 14;
      drawStar(ctx, bx + cs/2, by + cs/2, 5, cs*0.42, cs*0.18);
      ctx.shadowBlur = 0;
    }
  }

  // Snake
  state.snake.forEach((seg, i) => {
    const isHead = i === 0;
    const isTail = i === state.snake.length - 1;
    const x = seg.x * cs;
    const y = seg.y * cs;
    const pad = isHead ? 0 : 1;
    const r   = isHead ? 4 : 2;

    // Body gradient
    const ratio   = i / state.snake.length;
    const baseClr = CSS('--snake-body') || '#4eff91';
    const headClr = CSS('--snake-head') || '#a8ffbe';

    ctx.fillStyle = isHead ? headClr : lerpColor(headClr, baseClr, ratio * 0.7 + 0.3);
    ctx.shadowColor = isHead ? headClr : baseClr;
    ctx.shadowBlur  = isHead ? 10 : 4;

    ctx.beginPath();
    ctx.roundRect(x + pad, y + pad, cs - pad*2, cs - pad*2, r);
    ctx.fill();

    // Head details
    if (isHead) {
      ctx.fillStyle = CSS('--screen-bg') || '#0a1a0a';
      ctx.shadowBlur = 0;

      // Eyes based on direction
      let e1x, e1y, e2x, e2y;
      const ew = cs * 0.14, eh = cs * 0.14;
      if (state.dir === 'RIGHT') {
        e1x = x + cs*0.62; e1y = y + cs*0.22;
        e2x = x + cs*0.62; e2y = y + cs*0.62;
      } else if (state.dir === 'LEFT') {
        e1x = x + cs*0.24; e1y = y + cs*0.22;
        e2x = x + cs*0.24; e2y = y + cs*0.62;
      } else if (state.dir === 'UP') {
        e1x = x + cs*0.22; e1y = y + cs*0.24;
        e2x = x + cs*0.62; e2y = y + cs*0.24;
      } else {
        e1x = x + cs*0.22; e1y = y + cs*0.62;
        e2x = x + cs*0.62; e2y = y + cs*0.62;
      }
      ctx.fillRect(e1x, e1y, ew*1.6, eh*1.6);
      ctx.fillRect(e2x, e2y, ew*1.6, eh*1.6);
    }
  });

  ctx.shadowBlur = 0;
}

function drawStar(ctx, cx, cy, spikes, outerR, innerR) {
  let rot = (Math.PI / 2) * 3;
  const step = Math.PI / spikes;
  ctx.beginPath();
  ctx.moveTo(cx, cy - outerR);
  for (let i = 0; i < spikes; i++) {
    ctx.lineTo(cx + Math.cos(rot) * outerR, cy + Math.sin(rot) * outerR);
    rot += step;
    ctx.lineTo(cx + Math.cos(rot) * innerR, cy + Math.sin(rot) * innerR);
    rot += step;
  }
  ctx.lineTo(cx, cy - outerR);
  ctx.closePath();
  ctx.fill();
}

function lerpColor(c1, c2, t) {
  const h = (s) => {
    const r = parseInt(s.replace('#','').replace(/ /g,''), 16);
    return [(r>>16)&0xff, (r>>8)&0xff, r&0xff];
  };
  const a = h(c1.trim()), b = h(c2.trim());
  const r = Math.round(a[0] + (b[0]-a[0])*t);
  const g = Math.round(a[1] + (b[1]-a[1])*t);
  const bl= Math.round(a[2] + (b[2]-a[2])*t);
  return `rgb(${r},${g},${bl})`;
}

// ─────────────────────────────────────────────────────────────
//  UI HELPERS
// ─────────────────────────────────────────────────────────────
function updateHUD() {
  scoreEl.textContent = state.score;
  levelEl.textContent = state.level;
  bestEl.textContent  = Math.max(state.score, getBestScore());
}

function hideAllOverlays() {
  document.querySelectorAll('.overlay').forEach(o => o.style.display = 'none');
}

function showOverlay(id) {
  hideAllOverlays();
  document.getElementById(id).style.display = 'flex';
}

function showScorePop(text, cx, cy) {
  const screen = document.querySelector('.screen-inner');
  const cs     = cellSize();
  const rect   = screen.getBoundingClientRect();
  const scRect = canvas.getBoundingClientRect();
  const px     = (cx * cs + cs/2) / canvas.width  * scRect.width  + scRect.left - rect.left;
  const py     = (cy * cs)        / canvas.height * scRect.height + scRect.top  - rect.top;

  const el = document.createElement('div');
  el.className   = 'score-pop';
  el.textContent = text;
  el.style.left  = px + 'px';
  el.style.top   = py + 'px';
  screen.appendChild(el);
  setTimeout(() => el.remove(), 800);
}

function flashScreen() {
  const screen = document.querySelector('.screen-inner');
  const fl = document.createElement('div');
  fl.className = 'level-flash';
  screen.appendChild(fl);
  setTimeout(() => fl.remove(), 500);
}

function flashDie() {
  const canvas = document.getElementById('gameCanvas');
  let flashes = 0;
  const iv = setInterval(() => {
    canvas.style.filter = flashes%2===0 ? 'brightness(3) saturate(0)' : 'brightness(1)';
    if (++flashes >= 6) { clearInterval(iv); canvas.style.filter = ''; }
  }, 100);
}

// ─────────────────────────────────────────────────────────────
//  HIGH SCORE SCREEN
// ─────────────────────────────────────────────────────────────
function renderHighScores() {
  const hs = loadHighScores();
  if (!hs.length) {
    hsListEl.innerHTML = '<div class="hs-empty">NO SCORES YET</div>';
    return;
  }
  hsListEl.innerHTML = hs.map((e,i) => `
    <div class="hs-entry">
      <span class="hs-rank">#${i+1}</span>
      <span>${e.score}</span>
      <span>LVL${e.level}</span>
      <span>${e.date}</span>
    </div>
  `).join('');
}

// ─────────────────────────────────────────────────────────────
//  SETTINGS
// ─────────────────────────────────────────────────────────────
function applySettings() {
  speedLabel.textContent = SPEEDS[state.speedIdx].label;
  themeLabel.textContent = THEMES[state.themeIdx];
  wallsToggle.textContent = state.walls    ? 'ON' : 'OFF';
  soundToggle.textContent = state.soundOn  ? 'ON' : 'OFF';
  wallsToggle.classList.toggle('off', !state.walls);
  soundToggle.classList.toggle('off', !state.soundOn);
  document.body.setAttribute('data-theme', THEMES[state.themeIdx].toLowerCase());
  saveSettings();
  drawSnakeIcon();
}

document.getElementById('speedDown').onclick = () => { state.speedIdx = (state.speedIdx-1+SPEEDS.length)%SPEEDS.length; applySettings(); };
document.getElementById('speedUp').onclick   = () => { state.speedIdx = (state.speedIdx+1)%SPEEDS.length; applySettings(); };
document.getElementById('themeDown').onclick = () => { state.themeIdx = (state.themeIdx-1+THEMES.length)%THEMES.length; applySettings(); };
document.getElementById('themeUp').onclick   = () => { state.themeIdx = (state.themeIdx+1)%THEMES.length; applySettings(); };
document.getElementById('wallsToggle').onclick = () => { state.walls  = !state.walls;   applySettings(); };
document.getElementById('soundToggle').onclick = () => { state.soundOn= !state.soundOn; applySettings(); };

// ─────────────────────────────────────────────────────────────
//  MENU ACTIONS
// ─────────────────────────────────────────────────────────────
document.querySelectorAll('[data-action]').forEach(el => {
  el.addEventListener('click', () => handleAction(el.dataset.action));
  el.addEventListener('touchend', (e) => { e.preventDefault(); handleAction(el.dataset.action); });
});

function handleAction(action) {
  switch(action) {
    case 'start':    startGame(); break;
    case 'resume':   resumeGame(); break;
    case 'restart':  startGame(); break;
    case 'pause':    pauseGame(); break;
    case 'quit':
      clearInterval(state.loop);
      state.phase = 'start';
      showOverlay('startScreen');
      break;
    case 'highscore':
      renderHighScores();
      showOverlay('highscoreScreen');
      break;
    case 'settings':
      applySettings();
      showOverlay('settingsScreen');
      break;
  }
}

// ─────────────────────────────────────────────────────────────
//  BUTTON CONTROLS
// ─────────────────────────────────────────────────────────────
document.getElementById('btnStart').addEventListener('click', () => {
  if (state.phase === 'start' || state.phase === 'gameover') startGame();
});
document.getElementById('btnPause').addEventListener('click', pauseGame);
document.getElementById('btnCenter').addEventListener('click', pauseGame);

function pressDir(dir) {
  if (state.phase === 'start' || state.phase === 'gameover') { startGame(); return; }
  if (state.phase === 'paused') { resumeGame(); return; }
  if (state.phase !== 'playing') return;
  if (dir !== OPPOSITE[state.dir]) state.nextDir = dir;
}

document.getElementById('btnUp').addEventListener('click',    () => pressDir('UP'));
document.getElementById('btnDown').addEventListener('click',  () => pressDir('DOWN'));
document.getElementById('btnLeft').addEventListener('click',  () => pressDir('LEFT'));
document.getElementById('btnRight').addEventListener('click', () => pressDir('RIGHT'));

// Visual press feedback
['btnUp','btnDown','btnLeft','btnRight','btnCenter'].forEach(id => {
  const btn = document.getElementById(id);
  btn.addEventListener('touchstart', () => btn.classList.add('pressed'), { passive: true });
  btn.addEventListener('touchend',   () => btn.classList.remove('pressed'));
  btn.addEventListener('touchcancel',() => btn.classList.remove('pressed'));
  btn.addEventListener('mousedown',  () => btn.classList.add('pressed'));
  btn.addEventListener('mouseup',    () => btn.classList.remove('pressed'));
});

// ─────────────────────────────────────────────────────────────
//  KEYBOARD CONTROLS
// ─────────────────────────────────────────────────────────────
document.addEventListener('keydown', (e) => {
  switch(e.key) {
    case 'ArrowUp':    case 'w': case 'W': e.preventDefault(); pressDir('UP');    break;
    case 'ArrowDown':  case 's': case 'S': e.preventDefault(); pressDir('DOWN');  break;
    case 'ArrowLeft':  case 'a': case 'A': e.preventDefault(); pressDir('LEFT');  break;
    case 'ArrowRight': case 'd': case 'D': e.preventDefault(); pressDir('RIGHT'); break;
    case 'p': case 'P': case 'Escape': pauseGame(); break;
    case 'Enter': case ' ':
      if (state.phase === 'start' || state.phase === 'gameover') startGame();
      else if (state.phase === 'paused') resumeGame();
      break;
  }
});

// ─────────────────────────────────────────────────────────────
//  TOUCH SWIPE CONTROLS
// ─────────────────────────────────────────────────────────────
let touchStart = null;

const screen = document.querySelector('.screen-inner');
screen.addEventListener('touchstart', (e) => {
  touchStart = { x: e.touches[0].clientX, y: e.touches[0].clientY };
}, { passive: true });

screen.addEventListener('touchend', (e) => {
  if (!touchStart) return;
  const dx = e.changedTouches[0].clientX - touchStart.x;
  const dy = e.changedTouches[0].clientY - touchStart.y;
  const min = 20;
  if (Math.abs(dx) < min && Math.abs(dy) < min) { pauseGame(); return; }
  if (Math.abs(dx) > Math.abs(dy)) {
    pressDir(dx > 0 ? 'RIGHT' : 'LEFT');
  } else {
    pressDir(dy > 0 ? 'DOWN' : 'UP');
  }
  touchStart = null;
}, { passive: true });

// ─────────────────────────────────────────────────────────────
//  ANIMATION LOOP for idle draw (food pulse, bonus blink)
// ─────────────────────────────────────────────────────────────
function animationLoop() {
  if (state.phase === 'playing') draw();
  requestAnimationFrame(animationLoop);
}
animationLoop();

// ─────────────────────────────────────────────────────────────
//  PWA — SERVICE WORKER
// ─────────────────────────────────────────────────────────────
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  });
}

// PWA install prompt
let deferredPrompt = null;
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  showInstallBanner();
});

function showInstallBanner() {
  if (document.querySelector('.install-banner')) return;
  const banner = document.createElement('div');
  banner.className = 'install-banner';
  banner.innerHTML = `
    <span>📲 Install Snake Xenzia</span>
    <button id="installBtn">INSTALL</button>
    <button class="close-btn" id="closeBanner">✕</button>
  `;
  document.body.appendChild(banner);

  document.getElementById('installBtn').addEventListener('click', async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    deferredPrompt = null;
    banner.remove();
  });
  document.getElementById('closeBanner').addEventListener('click', () => banner.remove());
}

// ─────────────────────────────────────────────────────────────
//  INIT
// ─────────────────────────────────────────────────────────────
loadSettings();
applySettings();
resizeCanvas();
drawSnakeIcon();
updateHUD();
bestEl.textContent = getBestScore();
showOverlay('startScreen');

// Draw idle background on start
(function idleStart() {
  const cs = cellSize();
  ctx.fillStyle = CSS('--screen-bg') || '#0a1a0a';
  ctx.fillRect(0,0,canvas.width, canvas.height);

  ctx.strokeStyle = CSS('--grid-line') || 'rgba(78,255,145,0.07)';
  ctx.lineWidth = 0.5;
  for (let i=0;i<=GRID;i++) {
    ctx.beginPath(); ctx.moveTo(i*cs,0); ctx.lineTo(i*cs,canvas.height); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(0,i*cs); ctx.lineTo(canvas.width,i*cs); ctx.stroke();
  }
})();
